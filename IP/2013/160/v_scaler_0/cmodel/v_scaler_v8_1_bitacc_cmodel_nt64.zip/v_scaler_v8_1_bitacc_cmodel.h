//
//  (c) Copyright 2008-2009 Xilinx, Inc. All rights reserved.
//
//  This file contains confidential and proprietary information
//  of Xilinx, Inc. and is protected under U.S. and
//  international copyright and other intellectual property
//  laws.
//
//  DISCLAIMER
//  This disclaimer is not a license and does not grant any
//  rights to the materials distributed herewith. Except as
//  otherwise provided in a valid license issued to you by
//  Xilinx, and to the maximum extent permitted by applicable
//  law: (1) THESE MATERIALS ARE MADE AVAILABLE "AS IS" AND
//  WITH ALL FAULTS, AND XILINX HEREBY DISCLAIMS ALL WARRANTIES
//  AND CONDITIONS, EXPRESS, IMPLIED, OR STATUTORY, INCLUDING
//  BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, NON-
//  INFRINGEMENT, OR FITNESS FOR ANY PARTICULAR PURPOSE; and
//  (2) Xilinx shall not be liable (whether in contract or tort,
//  including negligence, or under any other theory of
//  liability) for any loss or damage of any kind or nature
//  related to, arising under or in connection with these
//  materials, including for any direct, or any indirect,
//  special, incidental, or consequential loss or damage
//  (including loss of data, profits, goodwill, or any type of
//  loss or damage suffered as a result of any action brought
//  by a third party) even if such damage or loss was
//  reasonably foreseeable or Xilinx had been advised of the
//  possibility of the same.
//
//  CRITICAL APPLICATIONS
//  Xilinx products are not designed or intended to be fail-
//  safe, or for use in any application requiring fail-safe
//  performance, such as life-support or safety devices or
//  systems, Class III medical devices, nuclear facilities,
//  applications related to the deployment of airbags, or any
//  other applications that could lead to death, personal
//  injury, or severe property or environmental damage
//  (individually and collectively, "Critical
//  Applications"). Customer assumes the sole risk and
//  liability of any use of Xilinx products in Critical
//  Applications, subject only to applicable laws and
//  regulations governing limitations on product liability.
//
//  THIS COPYRIGHT NOTICE AND DISCLAIMER MUST BE RETAINED AS
//  PART OF THIS FILE AT ALL TIMES. 
//-------------------------------------------------------------------

#ifndef v_scaler_v8_1_bitacc_cmodel_h
#define v_scaler_v8_1_bitacc_cmodel_h


#ifdef NT
#define DLLIMPORT __declspec(dllimport)
#else
#define DLLIMPORT
#endif

#ifndef Ip_xilinx_ip_v_scaler_v8_1_DLL
#define Ip_xilinx_ip_v_scaler_v8_1_DLL DLLIMPORT
#endif

#ifdef  __cplusplus
extern "C" {
#endif

#ifndef rgb_utils_h   // rgb_video_struct is defined here
#include "rgb_utils.h"
#endif
#ifndef yuv_utils_h   // yuv8_video_struct is defined here
#include "yuv_utils.h"
#endif
#ifndef video_utils_h   // video_struct is defined here
#include "video_utils.h"
#endif

struct coefs_struct{
  int** coefficients[4]; // 4 planes - HY, HC, VY, VC. Each plane is a 2d array defined by 1. Tap#; 2. Phase#.
};


struct xilinx_ip_v_scaler_v8_1_generics
{
/**
 * Scaler v2.1 Core Generics
 *
 * These are the only generics that influence the operation of this bit-accurate model.
 *
 *                          
 */
   int has_axi4_lite;
   int bits_per_component; 
   int num_h_taps; 
   int num_v_taps; 
   int max_phases; 
   int chroma_format; 
   int max_coef_sets;
   int Separate_YC_Coefs;
   int Separate_HV_Coefs;     
   int UserCoefsEnabled;
   int fixed_mode_crop_start_pixel; 
   int fixed_mode_crop_end_pixel; 
   int fixed_mode_crop_start_line; 
   int fixed_mode_crop_end_line; 
   int fixed_mode_source_h_size; 
   int fixed_mode_source_v_size; 
   int fixed_mode_output_h_size; 
   int fixed_mode_output_v_size; 
   int fixed_mode_num_h_phases; 
   int fixed_mode_num_v_phases; 
   int fixed_mode_hsf; 
   int fixed_mode_vsf; 
   struct coefs_struct init_coefs;

}; // xilinx_ip_v_scaler_v_0_generics


/**
 * Get list of default generics.
 *
 * @returns xilinx_ip_v_scaler_v8_1_generics  Default generics.
 */
Ip_xilinx_ip_v_scaler_v8_1_DLL int xilinx_ip_v_scaler_v8_1_get_default_generics(
   struct xilinx_ip_v_scaler_v8_1_generics *generics);

/**
 * Get list of default inputs.
 *
 * @returns 0 if successful, error code otherwise.
 */
int xilinx_ip_v_scaler_v8_1_get_default_inputs(
      struct xilinx_ip_v_scaler_v8_1_generics *generics, 
      struct xilinx_ip_v_scaler_v8_1_inputs *inputs);


/**
 * Structure to capture all inputs to the Scaler v6.0 C-Model.
 *
 * @param video_in         Input data and formatting, provided as a pointer to video_struct.
 *                         video_struct elements are:
 *                         data[plane][frame][row][col] containing 8-bit unsigned elements.
 *                         frames: number of frames in the data structure
 *                         rows  : number of Y rows in the data structure
 *                         cols  : number of Y columns in the data structure
 *                         mode  :
 *                         bits_per_component: number of bits stored per pixel (eg 8 for 8 bits/color channel)
 *                         The user is responsible for properly allocating the data field, and initializing all fields 
 *                         of the video_struct.
 * 
 */

struct xilinx_ip_v_scaler_v8_1_inputs
{
  struct    video_struct video_in;   //@- Contains the input data, and formatting (frames, rows, color)
  int       aperture_start_pixel;
  int       aperture_end_pixel;
  int       aperture_start_line;
  int       aperture_end_line;
  int       hsf;
  int       vsf;
  int       num_h_phases;
  int       num_v_phases;
  char      filename[256];
  struct    coefs_struct SingleFrameCoefs;
}; // end xilinx_ip_v_scaler_v8_1_inputs



/**
 * Structure to capture all outputs from the Scaler v6.0 C-Model.
 *
 * Before using this structure the user is responsible defining the output video_struct.
 * If the data structure in the output video_struct is preallocated, the Scaler model 
 * automatically uses the preallocated memory, but checks whether the formatting 
 * of the output video_stuct (number of frames, rows, columns) is compatible with the 
 * corresponding parameters of the input video_struct.
 *
 * @param video_out      Output data and formatting, provided as a pointer to video_struct.
 *                         video_struct elements are:
 *                         data[plane][frame][row][col] containing 8-bit unsigned elements.
 *                         frames: number of frames in the data structure
 *                         rows  : number of Y rows in the data structure
 *                         cols  : number of Y columns in the data structure
 *                         mode  :
 *                         bits_per_component: number of bits stored per pixel (eg 8 for 8 bits/color channel)
 */
/*
   IMPORTANT for Xilinx engineering:
   In Customer deliverable C-model, Coefficient text-file writing is temporarily disabled because we don't want text file IDs being sent into 
   the kernel in the 'input' and 'output' structures.
   In v6 of scaler Model, this issue will be addressed more appropriately.
*/
struct xilinx_ip_v_scaler_v8_1_outputs
{
   struct video_struct video_out;  //@- Contains the input data, and formatting (frames, rows, color)
   char     filename[256];
//   int      GenerateStimulusFiles;
//   FILE*    coefs_txtfid;
}; // xilinx_ip_v_scaler_v8_1_outputs

/**
 * Destroy the input / output video structure.
 *
 * @param *inputs       Pointer to the input structure which contains a video_struct structure 
 *                      to be destroyed (freed in memory).
 * @param *outputs      Pointers to the output structure which contains a video_struct structure 
 *                      to be destroyed (freed in memory).
 */
Ip_xilinx_ip_v_scaler_v8_1_DLL
void xilinx_ip_v_scaler_v8_1_destroy(
        struct xilinx_ip_v_scaler_v8_1_inputs *input, 
        struct xilinx_ip_v_scaler_v8_1_outputs *output);

/**
 * Simulate this bit-accurate C-Model.
 *
 * @param     generics   Inputs to the C-Model specified through Core Generator Generics
 * @param     inputs     Inputs to the C-Model specified through signals
 * @param     outputs    Outputs from this C-Model.
 *
 * @returns   Exit code   Zero for SUCCESS, Non-zero otherwise.
 */
Ip_xilinx_ip_v_scaler_v8_1_DLL
int xilinx_ip_v_scaler_v8_1_bitacc_simulate
(
   struct   xilinx_ip_v_scaler_v8_1_generics   generics,
   struct   xilinx_ip_v_scaler_v8_1_inputs     inputs,
   struct   xilinx_ip_v_scaler_v8_1_outputs*   outputs
);


int matlab_floor(float x);

int matlab_round(float x);

#ifdef  __cplusplus
}
#endif


#endif // v_scaler_v8_1_bitacc_cmodel_h 
